

<?php $__env->startSection('title', 'Mis Sorteos'); ?>
    
<?php $__env->startSection('content'); ?>
    <section class="container py-3">
        <h4 class="third-color text-uppercase">Mis sorteos</h4>
        <hr class="linea third-color">
        <table class="table">
            <tr>
                <td class="font-color">Imagen</td>
                <td class="font-color">Nombre</td>
                
                <td class="font-color">Fecha de sorteo</td>
                <td></td>
            </tr>
            <?php $__currentLoopData = $sorteos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sorteo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><img src="<?php echo e(asset('storage'.'/'.$sorteo->imagen)); ?>" alt="" class="imagen-icono"></td>
                    <td class="font-color align-middle"><?php echo e($sorteo->nombre); ?></td>
                    
                    <td class="font-color align-middle"><?php echo e($sorteo->fechaSorteo); ?></td>
                    <td class="align-middle">
                        <a href="<?php echo e($sorteo->link); ?>" target="_blank" class="btn boton-color text-white">Ver Sorteo</a>
                        <a href="<?php echo e(route('tickets.show', $sorteo->id)); ?>" class="btn boton-color text-white">Ver Tickets</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cliente.layouts.menu2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_rifa\resources\views/cliente/mis-sorteos.blade.php ENDPATH**/ ?>