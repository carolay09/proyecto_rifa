

<?php $__env->startSection('title', 'Carrito de compras'); ?>
    
<?php $__env->startSection('content'); ?>
    <section class="container py-5">
        <div class="row">
            <div class="col-9">
                <h4 class="third-color"><strong>PAGOS</strong></h4>
                <hr class="linea third-color">
                <div class="py-3">
                    <p>Si pagarás con YAPE o PLIN:</p>
                    <div class="metodos-pago d-flex justify-content-center">
                        <div class="d-flex px-5">
                            <img src="<?php echo e(asset('images/yape.png')); ?>" class="logo-metodo-pago" alt="">
                            <p class="px-3 m-0 d-flex align-items-center borde">982027069</p>
                        </div>
                        <div class="d-flex px-5">
                            <img src="<?php echo e(asset('images/plin.png')); ?>" class="logo-metodo-pago" alt="">
                            <p class="px-3 m-0 d-flex align-items-center borde">950012263</p>
                        </div>

                    </div>
                                       
               
                </div>
                <div class="py-3">
                    <p>Si pagarás con una transferencia bancaria:</p>
                    <div class="metodos-pago d-flex flex-column">
                        <div class="d-flex px-5 py-2 mx-auto">
                            <img src="<?php echo e(asset('images/interbank.png')); ?>" class="logo-metodo-pago" alt="">
                            <div class="d-inline-block borde">
                                <p class="px-3 m-0 d-flex align-items-center">Cuenta Ahorros Soles: 2003126615952</p>
                                <p class="px-3 m-0 d-flex align-items-center">Cuenta interbancaria: 00320001312661595237</p>
                            </div>
                        </div>
                        <div class="d-flex px-5 py-2 mx-auto">
                            <img src="<?php echo e(asset('images/bcp.png')); ?>" class="logo-metodo-pago" alt="">
                            <div class="d-inline-block">
                                <div class="borde">
                                    <p class="px-3 m-0 d-flex align-items-center">Cuenta Ahorros Soles: 19135899685005</p>
                                    <p class="px-3 m-0 d-flex align-items-center">Cuenta interbancaria: 00219113589968500554</p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>                
            </div>
            <div class="col-3">
                <h4 class="third-color"><strong>RESUMEN</strong></h4>
                <hr class="linea third-color">
                <div class="row">
                    <p class="col-12 col-md-6 font-color">Valor regular: </p>
                    <p class="col-12 col-md-6 font-color">S/. <?php echo e(number_format($sale->total, 2)); ?></p>
                </div>
                <div class="row">
                    <label for="" class="col-12 col-md-6 font-color">Descuento</label>
                    <?php if(isset($cupon)): ?>
                        <p class="col-12 col-md-6 text-danger">S/. <?php echo e(number_format($cupon->descuento, 2)); ?></p>
                    <?php else: ?>  
                        <p class="col-12 col-md-6 text-danger">S/. 0.00</p>  
                    <?php endif; ?>
                </div>
                <hr class="linea third-color my-4">
                <div class="row">
                    <p class="col-12 col-md-6 font-color">Total</p>
                    <?php if(isset($cupon)): ?>
                        <p class="col-12 col-md-6 text-success">S/. <?php echo e(number_format($sale->total-$cupon->descuento, 2)); ?></p>
                    <?php else: ?>
                        <p class="col-12 col-md-6 text-success">S/. <?php echo e(number_format($sale->total, 2)); ?></p>
                    <?php endif; ?>
                </div>

                <form action="<?php echo e(route('actualizar-estado', $sale->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <label for="" class="label-control py-3">Ingresa tu código de operación</label>
                    <div class="row">
                        <div class="col-12">
                            <input type="text" class="form-control borde-input" name="nroOperacion" value="<?php echo e(old('nroOperacion')); ?>">
                            <?php $__errorArgs = ['nroOperacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <?php if(Session::has('mensaje')): ?>
                                <div class="text-danger"><?php echo e(Session::get('mensaje')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="col-12 py-3">
                            <p class="text-center"><button type="submit" class="btn btn-danger">Finalizar compra</button></p>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cliente.layouts.menu2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_rifa\resources\views/cliente/metodos-pago.blade.php ENDPATH**/ ?>