

<?php $__env->startSection('title', 'Categorias|Editar'); ?>
    
<?php $__env->startSection('content'); ?>
    <section class="container">

    <h4 class="text-center">Edición de categorias</h4>

    <div class="row justify-content-md-center">
    <form action="<?php echo e(route('categories.update', $category)); ?>" method="post" enctype="multipart/form-data" class="py-5">

            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>

            <label for="" class="label-control">Nombre</label>
            <input type="text" name="nombre" class="form-control" value=" <?php echo e($category->nombre); ?>">
            <div class="row py-3">
                <div class="col-12 py-3">
                    <label for="" class="label-control">Imagen</label>
                    <img src="<?php echo e(asset('storage').'/'.$category->imagen); ?>" width="150px" class="pl-5" alt="">
                </div>
                <div class="col-12 py-3">
                    <input type="file" name="imagen" id="imagen" value="" class="">
                </div>
            </div>

            <p class="d-flex justify-content-center">
                <button type="submit" class="btn btn-primary mx-2">Guardar</button>
                <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-primary mx-2">Cancelar</a>
            </p>

        </form>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('administracion/layouts/dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_rifa\resources\views/administracion/category-edit.blade.php ENDPATH**/ ?>