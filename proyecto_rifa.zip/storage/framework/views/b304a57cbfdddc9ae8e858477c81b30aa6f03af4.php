

<?php $__env->startSection('title', 'Carrito de compras'); ?>
    
<?php $__env->startSection('content'); ?>
    <section class="container py-5">
        <div class="row">
            <div class="col-12 col-md-9">
                <h4 class="third-color"><strong>PRODUCTOS</strong></h4>
                <hr class="linea third-color">
                <?php if(count($detail_sales)): ?>
                <div class="table-responsive-xl">
                    <table class="table">
                        <?php
                            $total = 0;
                        ?>
                        <?php $__currentLoopData = $detail_sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail_sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="align-middle">
                                    <div class="d-flex flex-column align-items-center">
                                        <img src="<?php echo e(asset('storage'.'/'.$detail_sale->imagen)); ?>" alt="" class="imagen-icono">
                                    </div>
                                </td>
                                <td>
                                    <?php
                                        $total += $detail_sale->precioTicket * $detail_sale->cantidad;
                                        ?>
                                    <p><?php echo e($detail_sale->nombre); ?></p>
                                    <p>S/. <?php echo e(number_format($detail_sale->precio, 2)); ?></p>
                                </td>
                                <td class="align-middle">
                                    <?php if($detail_sale->cantidad == 1): ?>
                                        <?php echo e($detail_sale->cantidad); ?> ticket
                                    <?php else: ?>
                                        <?php echo e($detail_sale->cantidad); ?> tickets
                                    <?php endif; ?>
                                </td>
                                <td class="align-middle">
                                    S/. <?php echo e(number_format($detail_sale->precioTicket * $detail_sale->cantidad, 2)); ?>

                                </td>
                                <td class="align-middle">
                                    
                                    <form action="<?php echo e(route('detail_sales.destroy', $detail_sale->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <input type="hidden" name="cantidad" value="<?php echo e($detail_sale->cantidad); ?>">
                                        <input type="hidden" name="precio" value="<?php echo e($detail_sale->precio); ?>">
                                        <input type="hidden" name="idVenta" value="<?php echo e($sale->id); ?>">
                                        <button type="submit"><i class="fas fa-trash-alt"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center">Total</td>
                            <td></td>
                            <td></td>
                            <td>S/. <?php echo e(number_format($total, 2)); ?></td>
                            <td></td>
                        </tr>
                    </table>
                </div>
                
                <div class="d-flex justify-content-around my-5">
                    <a href="<?php echo e(url('/')); ?>" class="btn boton-color text-white">Seguir comprando</a>
                    <form action="<?php echo e(route('sales.update', $sale)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <input type="hidden" name="total" value="<?php echo e($total); ?>">
                        <button type="submit" class="btn boton-color text-white">Siguiente</button>
                    </form>
                </div>
            </div>
            <div class="col-12 col-md-3">
                
                <h4 class="third-color"><strong>RESUMEN</strong></h4>
                <hr class="linea third-color">
                <div class="row">
                    <p class="col-6 font-color">Valor regular: </p>
                    <p class="col-6 font-color">S/. <?php echo e(number_format($total, 2)); ?></p>
                </div>
                <?php if($sale_cupon == null): ?>                    
                
                    <div> 
                        <form action="<?php echo e(route('consultar_cupon')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="idVenta" value="<?php echo e($sale->id); ?>">
                            <label for=""><strong>Cupón de descuento</strong></label>
                            <input type="text" name="nombre" class="form-control borde-input">
                            <?php if(session()->has('mensaje')): ?>
                                <div class="text-danger">
                                    <?php echo e(session('mensaje')); ?>

                                </div>
                            <?php endif; ?>
                            <button type="submit" class="btn boton-color text-white my-1 px-4">Aplicar cupón</button>
                        </form>
                        <hr class="linea third-color my-4">
                        <div class="row">
                            <p class="col-12 col-md-6 font-color">Total</p>
                            <p class="col-12 col-md-6 font-color">S/. <?php echo e(number_format($total, 2)); ?></p>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="row">
                        <label for="" class="col-6 font-color">Descuento</label>
                        <p class="col-6 text-danger">S/. <?php echo e(number_format($sale_cupon->descuento, 2)); ?></p>
                    </div>
                    <hr class="linea third-color my-4">
                    <div class="row">
                        <p class="col-6 font-color">Total</p>
                        <?php if($total-$sale_cupon->descuento <= 0): ?>
                            <p class="col-6 font-color text-success">S/. 0.00</p>
                        <?php else: ?>
                            <p class="col-6 font-color text-success">S/. <?php echo e(number_format($total-$sale_cupon->descuento, 2)); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
            <?php else: ?>
                <p class="text-center py-5"><strong>No hay productos en su carrito</strong></p>
            <?php endif; ?>
            
        </div>
    </section>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cliente.layouts.menu2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_rifa\resources\views/cliente/carrito.blade.php ENDPATH**/ ?>