

<?php $__env->startSection('title'); ?>
    
<?php $__env->startSection('content'); ?>
    <section class="container">
        <div class="row">
            <div class="col-6">
                <img src="<?php echo e(asset('storage'.'/'.$product->imagen)); ?>" class="image-fluid" alt="" style="max-width: 100%">
                <div class="my-4 borde">
                    <p class="">Objetivo de la promoción</p>
                    <?php
                        $objetivo = $cantPartActual / $product->cantidadPart * 100;
                    ?>
                    <div id="myProgress" class="text-center">
                        <div id="myBar" style="width: <?php echo $objetivo."%"; ?>">                          
                            <div id="label"><?php echo $objetivo."%"; ?></div> 
                        </div>
                    </div>
                </div>
                <div class="borde w-50 text-center p-0">
                    <a href="<?php echo e(route('politicas')); ?>" style="text-decoration: none;" target="_blank">
                        <i class="fas fa-file-alt color-letra"></i>
                        <p class="p-0 m-0 color-letra" >TÉRMINOS Y CONDICIONES</p>
                    </a>
                </div>
            </div>
            <div class="col-6">
                <div class="w-75 mx-auto">
                    
                    <p class="mb-3 text-center nombre-prod py-3 fs-2"><strong><?php echo e($product->nombre); ?></strong></p>
                    <div class="borde tamano-letra">
                        <div class="mb-4">
                            <p class="p-0 m-0"><strong> Fecha del sorteo: </strong></p>
                            <p class="p-0 m-0"><?php echo e($product->fechaSorteo); ?></p>
                        </div>
                        <div class="mb-4">
                            <p class="p-0 m-0"><strong>Detalles del producto</strong></p>
                            <p class="p-0 m-0">Descripción: <?php echo e($product->descripcion); ?></p>
                            <p class="p-0 m-0">Marca: <?php echo e($product->marca); ?></p>
                        </div>
                        
                        <div class="">
                            <p class="p-0 m-0"><strong> Minorista aproximado</strong></p>
                            <p class="p-0 m-0">S/. <?php echo e(number_format ( $product->precio,2)); ?></p>
                        </div>

                        <div class="">
                            <p class="p-0 m-0"><strong> Precio de la rifa</strong></p>
                            <p class="p-0 m-0">S/. <?php echo e(number_format ( $product->precioTicket,2)); ?></p>
                        </div>

                        
                    </div>
                    
                    
                    
                    
                    <form action="<?php echo e(route('detail_sales.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="precio" value="<?php echo e($product->precioTicket); ?>">
                        <input type="hidden" name="idProducto" value="<?php echo e($product->id); ?>">
                        <p class="my-3">
                            <label for="">Seleccione la cantidad de tickets</label>
                            <input type="number" class="form-control text-center" name="cantidad" value="1">
                        </p>
                        <p class="text-center">
                            <button type="submit" class="btn boton-color text-white my-2 px-5">Agregar al carrito</button>
                        </p>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cliente/layouts/menu2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_rifa\resources\views/cliente/products-show.blade.php ENDPATH**/ ?>