

<?php $__env->startSection('title', 'Home'); ?>
    
<?php $__env->startSection('content'); ?>
    <section class="container">
        <h2 class="text-center my-5 text-uppercase third-color"><strong><?php echo e($categoria); ?></strong></h2>
        <div class="row">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                <div class="col-12 col-md-6 col-lg-4 card-group">
                    <div class="card mb-3">
                        <img src="<?php echo e(asset('storage').'/'.$product->imagen); ?>" alt="">
                        <div class="p-3">
                            <p class="borde px-3 py-0 m-0 d-inline-block">Fecha sorteo: <?php echo e($product->fechaSorteo); ?></p>
                            
                            
                            <h4 class="font-color my-1"><?php echo e($product->nombProd); ?></h4>
                            <div class="d-flex justify-content-between">
                                <p class="font-color m-0">Valor real del producto</p>
                                <p class="font-color m-0">S/. <?php echo e($product->precio); ?></p>
                            </div>
                            <div class="d-flex justify-content-between">
                                <p class="font-color m-0">Precio por ticket</p>
                                <p class="font-color m-0">S/. <?php echo e($product->precioTicket); ?></p>
                            </div>
                            <p class="text-center">
                                <a href="<?php echo e(route('products.show', $product->idProduct)); ?>" class="btn boton-color text-white">Comprar</a>
                            </p>
                        </div>
                    </div>
                </div>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cliente/layouts/menu2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_rifa\resources\views/cliente/products-index.blade.php ENDPATH**/ ?>