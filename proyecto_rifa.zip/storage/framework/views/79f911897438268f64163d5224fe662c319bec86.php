

<?php $__env->startSection('title', 'Mis Tickets'); ?>
    
<?php $__env->startSection('content'); ?>
    <section class="container py-3">
        <h4 class="third-color text-uppercase">Mis Tickets</h4>
        <hr class="linea third-color">
        <table class="table">
            <tr>
                <td class="font-color">Nro de Ticket : </td>
                <td></td>
            </tr>
            <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="font-color align-middle"><?php echo e($ticket->nroTicket); ?></td>
                    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cliente.layouts.menu2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_rifa\resources\views/cliente/mis-tickets.blade.php ENDPATH**/ ?>