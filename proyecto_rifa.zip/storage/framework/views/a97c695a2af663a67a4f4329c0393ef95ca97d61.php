

<?php $__env->startSection('title', 'Crear categoria'); ?>
    
<?php $__env->startSection('content'); ?>

<section class="container">

<h4 class="text-center">Creación de categorias</h4>
<div class="row justify-content-md-center">
    <form action="<?php echo e(route('categories.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <label for="" class="label-control">Nombre</label>
        <input type="text" name="nombre" class="form-control" placeholder="Ingrese la categoria">

        <div class="row py-3">
            <div class="col-12 py-3">
                <label for="" class="label-control">Imagen</label>
            </div>
            <div class="col-12 py-3">
                <input type="file" name="imagen" id="imagen" value="" class="">
            </div>
        </div>

        <p class="d-flex justify-content-center">
            <button type="submit" class="btn btn-primary mx-2">Guardar</button>
            <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-primary mx-2">Cancelar</a>
        </p>        

        
    </form>
</div>
</section>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('administracion/layouts/dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_rifa\resources\views/administracion/categories-create.blade.php ENDPATH**/ ?>