

<?php $__env->startSection('title', 'Dashboard'); ?>
    
<?php $__env->startSection('content'); ?>

<section class="container">
    <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary my-3">Crear usuario</a>
    <h4 class="text-center">Lista de usuarios</h4>
    <div class="table-responsive-xl">
    <table class="table" style="max-width: 50%">
        <tr>
            <td>Dni</td>
            <td>Nombre</td>
            <td>Apellido</td>
            <td>Telefono</td>
            <td>Direccion</td>
            <td>Correo</td>
            <td>Rol</td>
            <td>Estado</td>
            <td>Accion</td>
        </tr>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->dni); ?></td>
                <td><?php echo e($user->nombre); ?></td>
                <td><?php echo e($user->apellido); ?></td>
                <td><?php echo e($user->telefono); ?></td>
                <td><?php echo e($user->direccion); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->nombreRol); ?></td>
                <td><?php echo e($user->nombreEstado); ?></td>
                <td>
                    
                    <form action="<?php echo e(route('users.update_state', $user->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <input type="hidden" name="nombreEstado" value="<?php echo e($user->nombreEstado); ?>">
                        
                        <button type="submit" class="btn btn-danger">Cambiar estado</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('administracion/layouts/dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_rifa\resources\views/administracion/users-index.blade.php ENDPATH**/ ?>