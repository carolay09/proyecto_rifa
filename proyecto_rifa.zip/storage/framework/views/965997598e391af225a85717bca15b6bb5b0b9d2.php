

<?php $__env->startSection('title', 'Carrito de compras'); ?>
    
<?php $__env->startSection('content'); ?>
    <section class="container py-5">
        <div class="row">
            <div class="col-9">
                <h4 class="third-color"><strong>IDENTIFICACIÓN</strong></h4>
                <hr class="linea third-color">
                <p>Solicitamos únicamente la información esencial para la finalización de la compra</p>
                <form action="<?php echo e(route('users.update', $user)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class=" py-2">
                        <label for="" class="label-control">Correo</label>
                        <input type="email" class="form-control borde-input" name="email" value="<?php echo e($user->email); ?>">
                    </div>
                    <div class="row">
                        <div class="col-12 col-md-6 py-2">
                            <label for="" class="label-control">Nombre</label>
                            <input type="text" class="form-control borde-input" name="nombre" value="<?php echo e($user->nombre); ?>">
                        </div>
                        <div class="col-12 col-md-6 py-2">
                            <label for="" class="label-control">Apellidos</label>
                            <input type="text" class="form-control borde-input" name="apellido" value="<?php echo e($user->apellido); ?>">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 col-md-6 py-2">
                            <label for="" class="label-control">Documento de identidad</label>
                            <input id="dni" type="text" class="form-control borde-input  <?php $__errorArgs = ['dni'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="dni"  value="<?php echo e($user->dni); ?>" autocomplete="dni" autofocus>
                            <?php $__errorArgs = ['dni'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        
                        </div>

                        
                        <div class="col-12 col-md-6 py-2">
                            <label for="" class="label-control">Teléfono</label>
                            <input type="text" class="form-control borde-input" name="telefono" value="<?php echo e($user->telefono); ?>">
                        </div>
                        <div class="text-center py-2">
                            <button type="submit" class="btn boton-color text-white px-4">Siguiente</button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-3">
                <h4 class="third-color"><strong>RESUMEN</strong></h4>
                <hr class="linea third-color">
                <div class="row">
                    <p class="col-12 col-md-6 font-color">Valor regular: </p>
                    <p class="col-12 col-md-6 font-color">S/. <?php echo e(number_format($sale->total, 2)); ?></p>
                </div>
                <div class="row">
                    <label for="" class="col-12 col-md-6 font-color">Descuento</label>
                    <?php if($cupon == null): ?>
                        <p class="col-12 col-md-6 text-danger">S/. 0.00</p>  
                    <?php else: ?>  
                        <p class="col-12 col-md-6 text-danger">S/. <?php echo e(number_format($cupon->descuento, 2)); ?></p>
                    <?php endif; ?>
                </div>
                <hr class="linea third-color my-4">
                <div class="row">
                    <p class="col-12 col-md-6 font-color">Total</p>
                    <?php if($cupon == null): ?>
                        <p class="col-12 col-md-6 text-success">S/. <?php echo e(number_format($sale->total, 2)); ?></p>
                    <?php else: ?>
                        <p class="col-12 col-md-6 text-success">S/. <?php echo e(number_format($sale->total-$cupon->descuento, 2)); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cliente.layouts.menu2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_rifa\resources\views/cliente/formulario-venta.blade.php ENDPATH**/ ?>