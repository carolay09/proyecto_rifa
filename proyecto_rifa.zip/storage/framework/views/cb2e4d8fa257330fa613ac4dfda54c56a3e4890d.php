

<?php $__env->startSection('title', 'Revision de rifas'); ?>
    
<?php $__env->startSection('content'); ?>
    <section class="container">
        <div class="my-5">
            <h4 class="text-center mb-2">Pendientes de revision</h4>
            <table class="table">
                <tr>
                    <td class="text-center">Fecha de pago</td>
                    <td class="text-center">Monto a pagar</td>
                    <td class="text-center">Nro de operacion</td>
                    <td class="text-center">Accion</td>
                </tr>
                <?php $__currentLoopData = $rifasPend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rifaPend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"></td>
                        <td class="text-center"><?php echo e($rifaPend->total); ?></td>
                        <td class="text-center"><?php echo e($rifaPend->nroOperacion); ?></td>
                        <td class="d-flex justify-content-center">
                            <form action="<?php echo e(route('confirma-pago', $rifaPend->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <input type="hidden" name="idUsuario" value="<?php echo e($rifaPend->idUsuario); ?>">
                                <button type="submit" class="btn btn-primary">Confirmado</button>
                            </form>
                            <form action="<?php echo e(route('observa-pago', $rifaPend->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <button type="submit" class="btn btn-danger">Observado</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('administracion.layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_rifa\resources\views/administracion/revision-rifas.blade.php ENDPATH**/ ?>