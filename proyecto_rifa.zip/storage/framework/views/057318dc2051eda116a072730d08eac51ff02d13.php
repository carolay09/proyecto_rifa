

<?php $__env->startSection('title', 'Dashboard'); ?>
    
<?php $__env->startSection('content'); ?>

<section class="container">
    <h4 class="text-center">Tickets de la rifa</h4>
    <div class="table-responsive-xl">
    <table class="table">
        <tr>
            <td>Numero de ticket</td>
            <td>Dni</td>
            <td>Nombre</td>
            <td>Apellido</td>
            <td>Correo</td>
            <td>Telefono</td>
            <td></td>
        </tr>
        <?php $__currentLoopData = $raffle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($ticket->nroTicket); ?></td>
                <td><?php echo e($ticket->dni); ?></td>                
                <td><?php echo e($ticket->nombre); ?></td>
                <td><?php echo e($ticket->apellido); ?></td>
                <td><?php echo e($ticket->email); ?></td>
                <td><?php echo e($ticket->telefono); ?></td>
                <td>
                    <form action="<?php echo e(route('winners.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="nroTicket" value="<?php echo e($ticket->nroTicket); ?>">
                        <input type="hidden" name="idRifa" value="<?php echo e($ticket->idRifa); ?>">
                        <input type="hidden" name="idUsuario" value="<?php echo e($ticket->idUsuario); ?>">
                        <button type="submit" class="btn btn-primary">Elegir ganador</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </table>
    <a href="<?php echo e(route('raffles.index')); ?>" class="btn btn-primary">Regresar</a>
</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('administracion/layouts/dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_rifa\resources\views/administracion/tickets.blade.php ENDPATH**/ ?>