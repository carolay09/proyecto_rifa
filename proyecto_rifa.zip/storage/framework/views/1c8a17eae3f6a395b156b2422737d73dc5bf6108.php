

<?php $__env->startSection('title', 'LOTT|Home'); ?>
    
<?php $__env->startSection('content'); ?>
<div class="owl-container py-2 carousel-container">
    <div class="owl-carousel owl-theme">
        
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($category->nombreEstado == 'desbloqueado'): ?>
                <div> 
                    <div class="categoria-show">
                        <img class="img" src="<?php echo e(asset('storage').'/'.$category->imagen); ?>" alt=""> 
                        
                        <p class="d-flex justify-content-center">
                            
                            <a href="<?php echo e(route('producto_categoria', $category)); ?>" class="btn boton-color text-white btn-participa mb-3">Participa</a>
                        </p>
                    </div>
                    <h3 class="nombre-ctg"><?php echo e($category->nombre); ?></h3>
                </div>
            <?php endif; ?>
            <?php if($category->nombreEstado == 'bloqueado'): ?>
                <div> 
                    <div class="categoria-show">
                        <img class="img-bloqueado" src="<?php echo e(asset('storage').'/'.$category->imagen); ?>" alt=""> 
                        <img class="img-candado" src="<?php echo e(asset('images/comming-soon.jpeg')); ?>" alt="" style="width: 40%">
                        <p class="d-flex justify-content-center">
                            
                        </p>
                    </div>
                    <h3 class="nombre-ctg"><?php echo e($category->nombre); ?></h3>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<div class="section my-5">
    <p class="text-center h3 fw-bold secondary-color">¿Quiénes somos?</p>
    <article class="container articulo">
        Somos una empresa peruana que propone una forma alternativa de adquisición de bienes con costos elevados, ofreciendo la posibilidad de adquirir estos productos por medio de aportes simbólicos traducidos en tickets virtuales que, mediante sorteos benefician a los usuarios de nuestra plataforma.
    </article>
</div>
<div class="form-publicidad py-5">
    <div class="text-center">
        <p class="mensaje d-inline-block px-3">Manténgase al día con los sorteos vigentes</p>
    </div>
    <form action="<?php echo e(route('emails.store')); ?>" method="post" class="d-flex justify-content-center">
        <?php echo csrf_field(); ?>
        <input type="email" name="correoPublicidad" class="form-control w-25">
        <button type="submit" class="btn btn-danger">Enviar</button>
    </form>

</div>
<script>
    Swal.fire({
  title: 'Error!',
  text: 'Do you want to continue',
  icon: 'error',
  confirmButtonText: 'Cool'
})
</script>

    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/carousel.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cliente.layouts.menu2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_rifa\resources\views/cliente/home.blade.php ENDPATH**/ ?>