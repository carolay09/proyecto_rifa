

<?php $__env->startSection('title', 'Dashboard'); ?>
    
<?php $__env->startSection('content'); ?>

<section class="container">
    <h4 class="text-center">Lista de ventas</h4>
    <div class="table-responsive-xl">
    <table class="table">
        <tr>
            <td>Fecha</td>
            <td>Total</td>
            <td>Nro Operacion</td>
            <td>Usuario</td>
            <td>Estado</td>
            <td></td>
        </tr>
        <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($sale->fecha); ?></td>
                <td><?php echo e($sale->total); ?></td>
                <td><?php echo e($sale->nroOperacion); ?></td>
                <td><?php echo e($sale->nombreUsuario); ?></td>
                <td><?php echo e($sale->nombreEstado); ?></td>
                <td><a href="<?php echo e(route('sales.mostrar',$sale->id)); ?>" class="btn btn-primary">Ver Detalle</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('administracion/layouts/dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_rifa\resources\views/administracion/sales-index.blade.php ENDPATH**/ ?>