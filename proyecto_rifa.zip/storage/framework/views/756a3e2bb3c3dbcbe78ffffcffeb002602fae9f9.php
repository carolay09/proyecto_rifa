

<?php $__env->startSection('title', 'Dashboard'); ?>
    
<?php $__env->startSection('content'); ?>

<section class="container">
    <h4 class="text-center">Lista de mensajes</h4>
    <div class="table-responsive-xl">
    <table class="table">
        <tr>
            <td>Correo</td>
        </tr>
        <?php $__currentLoopData = $emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($email->email); ?></td>
                
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('administracion/layouts/dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_rifa\resources\views/administracion/emails-index.blade.php ENDPATH**/ ?>