

<?php $__env->startSection('title', 'Dashboard'); ?>
    
<?php $__env->startSection('content'); ?>

<section class="container">
    <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary my-3">Crear categoria</a>
    <h4 class="text-center">Lista de categorias</h4>
    <div class="table-responsive-xl">
    <table class="table">
        <tr>
            <td>Nombre</td>
            <td>Imagen</td>
            <td>Estado</td>
            <td>Accion</td>
        </tr>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($category->nombre); ?></td>
                <td><img src="<?php echo e(asset('storage').'/'.$category->imagen); ?>" width="100" alt=""></td>
                <td><?php echo e($category->nombreEstado); ?></td>
                <td>
                    
                    <a href="<?php echo e(route('categories.edit', $category->id)); ?>" class="btn btn-primary">Editar</a>
                    
                    
                    <form action="<?php echo e(route('categories.update-state', $category->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <input type="hidden" name="nombreEstado" value="<?php echo e($category->nombreEstado); ?>">
                        
                        <button type="submit" class="btn btn-danger">Cambiar estado</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('administracion/layouts/dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_rifa\resources\views/administracion/categories-index.blade.php ENDPATH**/ ?>