

<?php $__env->startSection('title', 'Mis Compras'); ?>
    
<?php $__env->startSection('content'); ?>
    <section class="container py-3">
        <h4 class="third-color text-uppercase">Mis compras</h4>
        <hr class="linea third-color">
        <div class="table-responsive-xl">
            <table class="table">
                <?php $__currentLoopData = $rifasRev; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rifaRev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><img src="<?php echo e(asset('storage'.'/'.$rifaRev->imagen)); ?>" alt="" class="imagen-icono"></td>
                    <td class="font-color align-middle"><?php echo e($rifaRev->nombre); ?></td>
                    <td class="font-color align-middle"><strong>S/. <?php echo e(number_format($rifaRev->precioTicket, 2)); ?></strong></td>
                    <td class="font-color align-middle text-danger">Validando código</td>
                    <td class="font-color align-middle"><?php echo e($rifaRev->fechaSorteo); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $rifasConf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rifaConf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><img src="<?php echo e(asset('storage'.'/'.$rifaConf->imagen)); ?>" alt="" class="imagen-icono"></td>
                    <td class="font-color align-middle"><?php echo e($rifaConf->nombre); ?></td>
                    <td class="font-color align-middle"><strong>S/. <?php echo e(number_format($rifaConf->precioTicket, 2)); ?></strong></td>
                    <td class="font-color align-middle text-success">Pago aprobado</td>
                    <td class="font-color align-middle"><?php echo e($rifaConf->fechaSorteo); ?></td>
                    <td class="align-middle"><a href="<?php echo e($rifaConf->link); ?>" target="_blank" class="btn boton-color text-white">Ver Sorteo</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>

    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cliente.layouts.menu2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_rifa\resources\views/cliente/mis-compras.blade.php ENDPATH**/ ?>