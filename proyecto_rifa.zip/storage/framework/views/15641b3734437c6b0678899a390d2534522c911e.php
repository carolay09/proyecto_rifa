

<?php $__env->startSection('title', 'Dashboard'); ?>
    
<?php $__env->startSection('content'); ?>
    
<section class="container">
    <a href="<?php echo e(route('coupons.create')); ?>" class="btn btn-primary my-3">Crear cupon</a>
    <h4 class="text-center">Lista de cupones</h4>
    <div class="table-responsive-xl">
    <table class="table">
        <tr>
            <td>Nombre</td>
            <td>Descuento</td>
            <td>Cantidad inicial</td>
            <td>Cantidad restante</td>
            <td>Estado</td>
            <td>Accion</td>
        </tr>
        <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($coupon->nombre); ?></td>
                <td><?php echo e($coupon->descuento); ?></td>
                <td><?php echo e($coupon->cantidad); ?></td>
                <td></td>
                <td><?php echo e($coupon->idEstado); ?></td>
                <td></td>
                
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('administracion/layouts/dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_rifa\resources\views/administracion/coupons-index.blade.php ENDPATH**/ ?>