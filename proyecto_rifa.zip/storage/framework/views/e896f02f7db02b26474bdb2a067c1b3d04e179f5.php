

<?php $__env->startSection('title', 'Rifas|Editar'); ?>
    
<?php $__env->startSection('content'); ?>
<section class="container">
    <form action="<?php echo e(route('raffles.update', $raffle)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        <label for="" class="label-control">Precio</label>
        <input type="text" name="precio" class="form-control" value=" <?php echo e($raffle->precioTicket); ?>">

        <label for="" class="label-control">Cantidad de Participantes</label>
        <input type="text" name="cantidad" class="form-control" value=" <?php echo e($raffle->cantidadPart); ?>">      

        <label for="" class="label-control">Producto</label>
        <select name="producto" id="" class="form-control">
            <?php echo e($produ = $raffle['idProducto']); ?>

             <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($produ == $product->id): ?>
                    <option value="<?php echo e($product['id']); ?>" selected><?php echo e($product['nombre']); ?></option>
                <?php else: ?>
                    <option value="<?php echo e($product['id']); ?>"><?php echo e($product['nombre']); ?></option>
                <?php endif; ?>
                    
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <label for="" class="label-control">Fecha sorteo</label>
        <input type="date" name="fechaSorteo" class="form-control" value=" <?php echo e($raffle->fechaSorteo); ?>">   

        <a href="<?php echo e(route('raffles.index')); ?>">Cancelar</a>
        <button type="submit">Guardar</button>
    </form>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('administracion/layouts/dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_rifa\resources\views/administracion/raffle-edit.blade.php ENDPATH**/ ?>