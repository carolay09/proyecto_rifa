

<?php $__env->startSection('title', 'Dashboard'); ?>
    
<?php $__env->startSection('content'); ?>

    <section class="container">
        <a href="<?php echo e(route('raffles.create')); ?>" class="btn btn-primary my-3">Crear rifa</a>
        <h4 class="text-center">Lista de rifas</h4>
        <div class="table-responsive-xl">
            <table class="table">
                <tr>
                    <td>Precio</td>
                    <td>Cantidad Participante</td>
                    <td>Producto</td>
                    <td>Fecha Sorteo</td>
                    <td>Link</td>
                    <td>Estado</td>
                    <td>Accion</td>
                </tr>
                <?php $__currentLoopData = $raffles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $raffle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($raffle->precioTicket); ?></td>
                        <td><?php echo e($raffle->cantidadPart); ?></td>
                        <td><?php echo e($raffle->nombreProducto); ?></td>
                        <td><?php echo e($raffle->fechaSorteo); ?></td>
                        <td><?php echo e($raffle->link); ?></td>
                        <td><?php echo e($raffle->nombreEstado); ?></td>
                        <td>
                            <a href="<?php echo e(route('raffles.edit', $raffle->id)); ?>" class="btn btn-primary">Editar</a>
                            
                            <a href="<?php echo e(route('raffles.mostrar', $raffle->id)); ?>" class="btn btn-primary">Ver Tickets</a>
                            <form action="<?php echo e(route('raffles.update_state', $raffle->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <input type="hidden" name="nombreEstado" value="<?php echo e($raffle->nombreEstado); ?>"> 
                                <button type="submit" class="btn btn-danger">Cambiar estado</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('administracion/layouts/dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_rifa\resources\views/administracion/raffles-index.blade.php ENDPATH**/ ?>