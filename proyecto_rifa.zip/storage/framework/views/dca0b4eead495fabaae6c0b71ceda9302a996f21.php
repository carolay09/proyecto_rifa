

<?php $__env->startSection('title', 'Dashboard'); ?>
    
<?php $__env->startSection('content'); ?>

<section class="container">
    <a href="<?php echo e(route('products.create.admi')); ?>" class="btn btn-primary my-3">Crear producto</a>
    <h4 class="text-center">Lista de productos</h4>
    <div class="table-responsive-xl">
        <table class="table">
            <tr>
                <td>Nombre</td>
                <td>Descripcion</td>
                <td>Marca</td>
                <td>Imagen</td>
                <td>Detalle</td>
                <td>Precio</td>
                <td>Categoria</td>
                <td>Estado</td>
                <td>Accion</td>
            </tr>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($product->nombre); ?></td>
                    <td><?php echo e($product->descripcion); ?></td>
                    <td><?php echo e($product->marca); ?></td>
                    
                    
                    <td><img src="<?php echo e(asset('storage').'/'.$product->imagen); ?>" width="100" alt=""></td>
                    <td><?php echo e($product->detalle); ?></td>
                    <td><?php echo e($product->precio); ?></td>
                    <td><?php echo e($product->nombreCategoria); ?></td>
                    <td><?php echo e($product->nombreEstado); ?></td>
                    <td>
                        <a href="<?php echo e(route('products.edit.admi', $product->id)); ?>" class="btn btn-primary">Editar</a>
                                   
                        <form action="<?php echo e(route('products.update_state', $product->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <input type="hidden" name="nombreEstado" value="<?php echo e($product->nombreEstado); ?>">
                            
                            <button type="submit" class="btn btn-danger">Cambiar estado</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    
    </div>
</section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('administracion/layouts/dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_rifa\resources\views/administracion/products-index.blade.php ENDPATH**/ ?>