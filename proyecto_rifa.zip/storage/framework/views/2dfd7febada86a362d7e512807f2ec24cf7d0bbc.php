

<?php $__env->startSection('title', 'Dashboard'); ?>
    
<?php $__env->startSection('content'); ?>

<section class="container">
    <h4 class="text-center">Detalle de venta</h4>
    <div class="table-responsive-xl">
    <table class="table">
        <tr>
            <td>Cantidad</td>
            <td>Precio</td>
            <td>Total</td>
            <td>Rifa</td>
        </tr>
        <?php $__currentLoopData = $sale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail_sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($detail_sale->cantidad); ?></td>
                <td><?php echo e($detail_sale->precio); ?></td>
                <td><?php echo e($detail_sale->total); ?></td>
                <td><?php echo e($detail_sale->idRaffle); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </table>
    <a href="<?php echo e(route('sales.index')); ?>" class="btn btn-primary">Regresar</a>
</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('administracion/layouts/dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_rifa\resources\views/administracion/detail_sales.blade.php ENDPATH**/ ?>