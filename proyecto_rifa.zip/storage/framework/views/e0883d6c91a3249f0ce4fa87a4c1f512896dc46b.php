

<?php $__env->startSection('title', 'Productos|Editar'); ?>
    
<?php $__env->startSection('content'); ?>
    <section class="container">
        <h4 class="text-center">Edición de productos</h4>

        <div class="row justify-content-md-center">
        <form action="<?php echo e(route('products.update.admi', $product)); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>

            <label for="" class="label-control">Nombre</label>
            <input type="text" name="nombre" class="form-control" value=" <?php echo e($product->nombre); ?>">

            <label for="" class="label-control">Descripcion</label>
            <input type="text" name="descripcion" class="form-control" value="<?php echo e($product->descripcion); ?>">

            <label for="" class="label-control">Marca</label>
            <input type="text" name="marca" class="form-control" value="<?php echo e($product->marca); ?>">

            <div class="row py-3">
                <div class="col-12 py-3">
                    <label for="" class="label-control">Imagen</label>
                    <img src="<?php echo e(asset('storage').'/'.$product->imagen); ?>" width="150px" class="pl-5" alt="">
                </div>
                <div class="col-12 py-3">
                    <input type="file" name="imagen" id="imagen" value="" class="">
                </div>
            </div>
                  
                <label for="" class="label-control">Detalle</label>
                <input type="text" name="detalle" class="form-control" value="<?php echo e($product->detalle); ?>">

                <label for="" class="label-control">Precio</label>
            <input type="number" name="precio" class="form-control" value="<?php echo e($product->precio); ?>">

            <label for="" class="label-control">Categoria</label>
            <select name="categoria" id="" class="form-control">
                <?php echo e($cate = $product['idCategoria']); ?>

                 <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($cate == $category->id): ?>
                        <option value="<?php echo e($category['id']); ?>" selected><?php echo e($category['nombre']); ?></option>
                    <?php else: ?>
                        <option value="<?php echo e($category['id']); ?>"><?php echo e($category['nombre']); ?></option>
                    <?php endif; ?>
                        
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <p class="d-flex justify-content-center py-3">
                <button type="submit" class="btn btn-primary mx-2">Guardar</button>
                <a href="<?php echo e(route('products.index.admi')); ?>" class="btn btn-primary mx-2">Cancelar</a>
            </p>
        </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('administracion/layouts/dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_rifa\resources\views/administracion/product-edit.blade.php ENDPATH**/ ?>