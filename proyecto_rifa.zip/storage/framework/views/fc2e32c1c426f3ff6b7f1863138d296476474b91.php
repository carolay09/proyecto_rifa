

<?php $__env->startSection('title', 'Mis Rifas'); ?>
    
<?php $__env->startSection('content'); ?>
    <section class="container">
        <div class="my-5">
            <h4 class="text-center mb-2">Pendientes a pagar</h4>
            <div class="table-reponsive-xl">
                <table class="table">
                    <tr>
                        <td class="text-center">Fecha maxima de pago</td>
                        <td class="text-center">Monto a pagar</td>
                        <td class="text-center"></td>
                    </tr>
                    <?php $__currentLoopData = $rifasEsp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rifaRev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center"><?php echo e($rifaRev->fechaSorteo); ?></td>
                            <td class="text-center"><?php echo e($rifaRev->total); ?></td>
                            <td>
                                <form action="<?php echo e(route('actualizar-estado', $rifaRev)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <div class="d-flex">
                                        <input type="text" name="nroOperacion" class="form-control" placeholder="Ingrese nro de operación">
                                        <button type="submit" class="btn btn-primary">Enviar</button>
                                    </div>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
        <div class="my-5">
            <h4 class="text-center mb-2">En revision</h4>
            <table class="table">
                <tr>
                    <td class="text-center">Monto pagado</td>
                    <td class="text-center">Fecha maxima de confirmacion</td>
                </tr>
                <?php $__currentLoopData = $rifasRev; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rifaRev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><?php echo e($rifaRev->total); ?></td>
                        <td>
                           
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
        <div class="my-5">
            <h4 class="text-center mb-2">Mis Rifas Confirmadas</h4>
            <table class="table">
                <tr>
                    <td class="text-center">Producto</td>
                    <td class="text-center">Fecha</td>
                    <td class="text-center">Cantidad de boletos</td>
                    <td class="text-center">Meta de participantes</td>
                </tr>
                <?php $__currentLoopData = $rifasConf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rifaConf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($rifaConf->nombre); ?></td>
                        <td class="text-center"><?php echo e($rifaConf->fechaSorteo); ?></td>
                        <td class="text-center"><?php echo e($rifaConf->cantidad); ?></td>
                        <td></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
        <div class="my-5">
            <h4 class="text-center mb-2">Mis Rifas Observadas</h4>
            <table class="table">
                <tr>
                    <td class="text-center">Producto</td>
                    <td class="text-center">Fecha</td>
                    <td class="text-center">Cantidad de boletos</td>
                    <td class="text-center">Meta de participantes</td>
                </tr>
                <?php $__currentLoopData = $rifasObs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rifaObs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($rifaObs->nombre); ?></td>
                        <td class="text-center"><?php echo e($rifaObs->fechaSorteo); ?></td>
                        <td class="text-center"><?php echo e($rifaObs->cantidad); ?></td>
                        <td></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cliente.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_rifa\resources\views/cliente/mis-rifas.blade.php ENDPATH**/ ?>