

<?php $__env->startSection('title', 'Usuarios|Editar'); ?>
    
<?php $__env->startSection('content'); ?>
    <section class="container">
        <form action="<?php echo e(route('users.update', $user)); ?>" method="post" >
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>

            <label for="" class="label-control">Nombre</label>
            <input type="text" name="nombre" class="form-control" value=" <?php echo e($user->nombre); ?>">

            <label for="" class="label-control">Apellido</label>
            <input type="text" name="apellido" class="form-control" value=" <?php echo e($user->apellido); ?>">

            <label for="" class="label-control">Telefono</label>
            <input type="text" name="telefono" class="form-control" value=" <?php echo e($user->telefono); ?>">

            <label for="" class="label-control">Direccion</label>
            <input type="text" name="direccion" class="form-control" value=" <?php echo e($user->direccion); ?>">

            <label for="" class="label-control">Correo</label>
            <input type="text" name="email" class="form-control" value=" <?php echo e($user->email); ?>">

            <label for="" class="label-control">Clave</label>
            <input type="text" name="password" class="form-control" value=" <?php echo e($user->password); ?>">

            
    
             <a href="<?php echo e(route('users.index')); ?>">Cancelar</a>
            <button type="submit">Guardar</button>

        </form>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('administracion/layouts/dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_rifa\resources\views/administracion/user-edit.blade.php ENDPATH**/ ?>