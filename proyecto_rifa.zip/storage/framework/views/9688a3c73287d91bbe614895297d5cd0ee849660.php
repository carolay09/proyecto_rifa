

<?php $__env->startSection('title', 'Crear rifa'); ?>
    
<?php $__env->startSection('content'); ?>
<section class="container">

    <h4 class="text-center">Creación de rifas</h4>
    <div class="row justify-content-md-center">

    <form action="<?php echo e(route('raffles.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label for="" class="label-control">Precio</label>
        <input type="text" name="precio" class="form-control" placeholder="Ingrese el precio">

        <label for="" class="label-control">Cantidad de Participantes</label>
        <input type="text" name="cantidad" class="form-control" placeholder="Ingrese cantidad de participante">      

        <label for="" class="label-control">Producto</label>
        <select name="producto" id="" class="form-control">
            <option value="" selected>Seleccione</option>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($product['id']); ?>"><?php echo e($product['nombre']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <label for="" class="label-control">Fecha sorteo</label>
        <input type="date" name="fecha" class="form-control" placeholder="Ingrese fecha de sorteo">   

        <label for="" class="label-control">Link de la reunión</label>
        <input type="text" name="link" class="form-control" placeholder="Ingrese link">     

        <input type="hidden" name="idEstado" value="2">

        <p class="d-flex justify-content-center py-3">
            <button type="submit" class="btn btn-primary mx-2">Guardar</button>
            <a href="<?php echo e(route('raffles.index')); ?>" class="btn btn-primary mx-2">Cancelar</a>
        </p>

    </form>
</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('administracion/layouts/dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_rifa\resources\views/administracion/raffles-create.blade.php ENDPATH**/ ?>