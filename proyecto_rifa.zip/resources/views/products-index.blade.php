@extends('layouts/menu')

@section('title', 'Home')
    
@section('content')


    
@endsection